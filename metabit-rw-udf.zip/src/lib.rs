use arrow_udf::function;
use prost::Message;

pub mod proto {
    include!(concat!(env!("OUT_DIR"), "/metabit.rs"));
}

#[function("proto_header_decode(bytea) -> struct<stream:varchar,pan:varchar>")]
fn proto_header_decode(data: &[u8]) -> (String, String) {
    let data_key = proto::DataKey::decode(data).expect("decode header");
    (data_key.stream, data_key.pan)
}

#[function(
    r#"proto_decode_snapshot(bytea) -> struct<
        ds:bigint,
        instance:varchar,
        marketType:varchar,
        eventTime:bigint,
        logTime:bigint,
        totalValue:double precision,
        cash:double precision,
        frozenCash:double precision,
        dailyPni:double precision,
        marketValue:double precision,
        margin:double precision,
        commission:double precision,
        serverMargin:double precision,
        serverCommission:double precision
    >"#
)]
fn proto_decode_snapshot(
    data: &[u8],
) -> (
    i64,
    String,
    String,
    i64,
    i64,
    f64,
    f64,
    f64,
    f64,
    f64,
    f64,
    f64,
    f64,
    f64,
) {
    let snapshot = proto::AccountSnapshot::decode(data).expect("decode snapshot");
    (
        snapshot.ds,
        snapshot.instance,
        snapshot.market_type,
        snapshot.event_time,
        snapshot.log_time,
        snapshot.total_value,
        snapshot.cash,
        snapshot.frozen_cash,
        snapshot.daily_pnl,
        snapshot.market_value,
        snapshot.margin,
        snapshot.commission,
        snapshot.server_margin,
        snapshot.server_commission,
    )
}

#[function(
    r#"proto_decode_trade(bytea) -> struct<
        ds: bigint,
        instance: varchar,
        marketType: varchar,
        eventTime: bigint,
        logTime: bigint,
        orderRef: varchar,
        code: varchar,
        direction: varchar,
        offset: varchar,
        value: double precision,
        price: double precision,
        volume: double precision
    >"#
)]
fn proto_decode_trade(
    data: &[u8],
) -> (
    i64,
    String,
    String,
    i64,
    i64,
    String,
    String,
    String,
    String,
    f64,
    f64,
    f64,
) {
    let trade = proto::Trade::decode(data).expect("decode trade");
    (
        trade.ds,
        trade.instance,
        trade.market_type,
        trade.event_time,
        trade.log_time,
        trade.order_ref,
        trade.code,
        trade.direction,
        trade.offset,
        trade.value,
        trade.price,
        trade.volume,
    )
}

#[function(
    r#"proto_decode_elixir_instrument(bytea) -> struct<
        ds: bigint,
        instance: varchar,
        marketType: varchar,
        eventTime: bigint,
        logTime: bigint,
        columns: varchar[],
        rows: varchar[]
    >"#
)]
fn proto_decode_elixir_instrument(
    data: &[u8],
) -> (
    i64,
    String,
    String,
    i64,
    i64,
    Vec<Option<String>>,
    Vec<Option<String>>,
) {
    proto_decode_elixir_instrument_inner(data)
}

fn proto_decode_elixir_instrument_inner(
    data: &[u8],
) -> (
    i64,
    String,
    String,
    i64,
    i64,
    Vec<Option<String>>,
    Vec<Option<String>>,
) {
    let instrument = proto::ElixirInstrument::decode(data).expect("decode elixir instrument");
    let rows: Vec<_> = instrument
        .rows
        .iter()
        .map(|row| {
            let row = serde_json::to_string(&row).unwrap();

            Some(row)
        })
        .collect();
    (
        instrument.ds,
        instrument.instance,
        instrument.market_type,
        instrument.event_time,
        instrument.log_time,
        instrument.columns.into_iter().map(Some).collect(),
        rows,
    )
}
