fn main() {
    let mut prost_build = prost_build::Config::new();
    prost_build
        .type_attribute(
            ".metabit.ElixirInstrument.Row",
            "#[derive(serde::Serialize)]",
        )
        .compile_protos(
            &["src/proto/dataKey.proto", "src/proto/dataValue.proto"],
            &["src"],
        )
        .unwrap();
}
